#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>

// build the full path first
    // full path = intro path (long jawn) + userprog path
// print to prompt
// if cd is called print the full path
// if cd w/ argument
int main(int argc, char *argv[]) {

}

